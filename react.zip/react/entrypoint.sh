#!/bin/sh

FORCE_COLOR=true npm start | cat